## ---- include = FALSE----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup---------------------------------------------------------------
library(homelessness)

## ----message=FALSE-------------------------------------------------------
library(dplyr)
data("gini", package = "homelessness")
gini %>%
  group_by(year) %>%
  summarize(avg_gini = mean(gini, na.rm = TRUE))

## ------------------------------------------------------------------------
library(ggplot2)
data("homeless", package = "homelessness")
aggregated %>% 
  filter(state %in%  c("California", "Oregon", "Washington", "Hawaii", "Alaska"),
         year %in% 2010:2017) %>%
           ggplot(aes(x = year, y = share_homeless, group = state, color = state)) + geom_line() +
  labs(y = "Homeless Population per 10,000 People",
       title = "Change in Homeless Population in Western U.S. States")

## ------------------------------------------------------------------------
data("unemployment", package = "homelessness")
unemployment %>% filter(year == 2018) %>%
  ggplot(aes(y = unemployment)) + geom_boxplot() + coord_flip()

## ------------------------------------------------------------------------
data("aggregated", package = "homelessness")
summary(lm(share_homeless ~ gini + I(gini^2) + unemployment + rentincome + I(rentincome^2) + log(gdp), data = aggregated))
ggplot(aggregated, aes(x = unemployment, y = share_homeless)) + geom_point() + geom_smooth(method = "lm", se = FALSE)

## ------------------------------------------------------------------------
data("gdp")
hist(gdp$gdp)

## ------------------------------------------------------------------------
data("population", package = "homelessness")
population %>%
  group_by(year) %>%
  summarize(USpopulation = sum(population, na.rm = TRUE))

## ------------------------------------------------------------------------
data("rentincome", package = "homelessness")
rentincome %>%
  group_by(year) %>%
  summarize(avg_value = mean(rentincome, na.rm = TRUE),
            median_value = median(rentincome, na.rm = TRUE))

